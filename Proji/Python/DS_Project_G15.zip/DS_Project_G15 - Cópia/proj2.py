
import pandas as pd

#Storing the data
data = pd.read_csv ('small_ca_monthly_data.csv') #reads the file
df=pd.DataFrame(data) #stores the data in a dataframe

#Discretize targer parameter
aux = pd.get_dummies(df,columns=['target'])
df['target'] = aux['target_True']
df = df.dropna(axis=1, how='all')
#??argumentos do dropna

#Check the dimensions of the dataset
print("Number of rows:", df.shape[0])
print("Number of columns:", df.shape[1])

#Check the data types of the columns
df.dtypes.to_csv('dtypes.csv')

#Check for missing values
df.isnull().sum().to_csv('null_sum.csv')

#Check the descriptive statistics of the numerical columns
df.describe().to_csv('description.csv')


#Check the distribution of each numerical column using histograms
import matplotlib.pyplot as plt
f1 = plt.figure()
df.hist(figsize=(60, 60))
plt.savefig('hist.pdf')

#Check the correlation between numerical columns
import seaborn as sns
f2 = plt.figure()
corr = df.corr()
plt.figure(figsize = (60,60))
sns.heatmap(corr, annot=True)
plt.savefig('correlation.pdf')

#Check the distribution of the target variable (if applicable)
f3 = plt.figure()
sns.countplot(x="target", data=df)
plt.savefig('target_dist.pdf')

from pandas import read_csv
from pandas.plotting import register_matplotlib_converters
from matplotlib.pyplot import subplots, savefig, show
from ds_charts import get_variable_types, HEIGHT


#numeric_vars = get_variable_types(df)['Numeric']
#if [] == numeric_vars:
    #raise ValueError('There are no numeric variables.')



#from matplotlib.pyplot import figure, savefig, show
#from ds_charts import bar_chart

#figure(figsize=(4,2))
#values = {'nr records': df.shape[0], 'nr variables': df.shape[1]}
#bar_chart(list(values.keys()), list(values.values()), title='Nr of records vs nr variables')
#savefig('records_variables.pdf')
#show()

from pandas import DataFrame
def get_variable_types(df: DataFrame) -> dict:
    variable_types: dict = {
        'Numeric': [],
        'Binary': [],
        'Date': [],
        'Symbolic': []
    }
    for c in df.columns:
        uniques = df[c].dropna(inplace=False).unique()
        if len(uniques) == 2:
            variable_types['Binary'].append(c)
            df[c].astype('bool')
        elif df[c].dtype == 'datetime64':
            variable_types['Date'].append(c)
        elif df[c].dtype == 'int':
            variable_types['Numeric'].append(c)
        elif df[c].dtype == 'float':
            variable_types['Numeric'].append(c)
        else:
            df[c].astype('category')
            variable_types['Symbolic'].append(c)

    return variable_types

from matplotlib.pyplot import figure, savefig, show
from ds_charts import bar_chart, get_variable_types

variable_types = get_variable_types(df)
print(variable_types)
counts = {}
for tp in variable_types.keys():
    counts[tp] = len(variable_types[tp])
figure(figsize=(4,2))
bar_chart(list(counts.keys()), list(counts.values()), title='Nr of variables per type')
savefig('variable_types.pdf')
show()