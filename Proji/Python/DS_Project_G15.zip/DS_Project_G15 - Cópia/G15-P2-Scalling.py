from pandas import read_csv
from pandas.plotting import register_matplotlib_converters
import pandas as pd
from ds_charts import get_variable_types

register_matplotlib_converters()
file = 'ds_G15'
filename = f'data/{file}_mv_mean.csv'
df = read_csv(filename, index_col='station', na_values='', parse_dates=True, infer_datetime_format=True)

#Scalling

variable_types = get_variable_types(df)
numeric_vars = variable_types['Numeric']
symbolic_vars = variable_types['Symbolic']
boolean_vars = variable_types['Binary']

df_nr = df[numeric_vars]
df_sb = df[symbolic_vars]
df_bool = df[boolean_vars]

from sklearn.preprocessing import StandardScaler
from pandas import DataFrame, concat

# z-score scaler
transf = StandardScaler(with_mean=True, with_std=True, copy=True).fit(df_nr)
tmp = DataFrame(transf.transform(df_nr), index=df.index, columns= numeric_vars)
norm_data_zscore = concat([tmp,df_bool], axis=1)
norm_data_zscore.to_csv(f'data/{file}_scl_zscore.csv', index=False)

from sklearn.preprocessing import MinMaxScaler
from pandas import DataFrame, concat

# min-max scaler
transf = MinMaxScaler(feature_range=(0, 1), copy=True).fit(df_nr)
tmp = DataFrame(transf.transform(df_nr), index=df.index, columns= numeric_vars)
norm_data_minmax = concat([tmp, df_bool], axis=1)
norm_data_minmax.to_csv(f'data/{file}_scl_minmax.csv', index=False)

from matplotlib.pyplot import subplots, savefig, show

fig, axs = subplots(1, 3, figsize=(20,10),squeeze=False)
axs[0, 0].set_title('Original data')
df.boxplot(ax=axs[0, 0])
axs[0, 1].set_title('Z-score normalization')
norm_data_zscore.boxplot(ax=axs[0, 1])
axs[0, 2].set_title('MinMax normalization')
norm_data_minmax.boxplot(ax=axs[0, 2])
savefig('data/results/zscore_vs_minmax.png')

#Train-Test Splitting

#Para o codigo que se segue deviamos ter um ficheiro com os dados de treino e outro com os de teste
import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np

df = read_csv(f'data/{file}_scl_minmax.csv')

train_data, test_data = train_test_split(df, test_size=0.2, random_state=0)

# Save your training and test data into separate files
train_data.to_csv(f'data/{file}_scl_minmax_train.csv', index=False)
test_data.to_csv(f'data/{file}_scl_minmax_test.csv', index=False)

# Save your training and test data into separate Numpy files
np.save(f'data/{file}_scl_minmax_train', train_data)
np.save(f'data/{file}_scl_minmax_test', test_data)

#NaiveBayes

from numpy import ndarray
from pandas import DataFrame, read_csv, unique
from matplotlib.pyplot import figure, savefig, show
from sklearn.naive_bayes import GaussianNB
from ds_charts import plot_evaluation_results, bar_chart

target = 'target'

train: DataFrame = read_csv(f'data/{file}_scl_minmax_train.csv')
trnY: ndarray = train.pop(target).values
trnX: ndarray = train.values
labels = unique(trnY)
labels.sort()

test: DataFrame = read_csv(f'data/{file}_scl_minmax_test.csv')
tstY: ndarray = test.pop(target).values
tstX: ndarray = test.values

clf = GaussianNB()
clf.fit(trnX, trnY)
prd_trn = clf.predict(trnX)
prd_tst = clf.predict(tstX)
plot_evaluation_results(labels, trnY, prd_trn, tstY, prd_tst)
savefig(f'data/results/{file}_scl_nb_minmax.png')

#Comparison of NB models

from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB, CategoricalNB
from sklearn.metrics import accuracy_score

estimators = {'GaussianNB': GaussianNB(),
              #'MultinomialNB': MultinomialNB(),
              #'BernoulliNB': BernoulliNB()
              #'CategoricalNB': CategoricalNB
              }

xvalues = []
yvalues = []
for clf in estimators:
    xvalues.append(clf)
    estimators[clf].fit(trnX, trnY)
    prdY = estimators[clf].predict(tstX)
    yvalues.append(accuracy_score(tstY, prdY))

figure()
bar_chart(xvalues, yvalues, title='Comparison of Naive Bayes Models', ylabel='accuracy', percentage=True)
savefig(f'data/results/{file}_scl_nb_study_minmax.png')

print('\nend of script\n')