from pandas import read_csv
from pandas.plotting import register_matplotlib_converters
import pandas as pd


register_matplotlib_converters()
file = 'ds_G15'
filename = f'data/{file}_mv_mean.csv'
df = read_csv(filename, index_col='station', na_values='', parse_dates=True, infer_datetime_format=True)

from ds_charts import get_variable_types

#Balancing

from pandas import read_csv
from matplotlib.pyplot import figure, savefig, show
from ds_charts import bar_chart


original = read_csv(filename, index_col='station', na_values='', parse_dates=True, infer_datetime_format=True)
class_var = 'target'
target_count = original[class_var].value_counts()
positive_class = target_count.idxmin()
negative_class = target_count.idxmax()
#ind_positive_class = target_count.index.get_loc(positive_class)
print('Minority class=', positive_class, ':', target_count[positive_class])
print('Majority class=', negative_class, ':', target_count[negative_class])
print('Proportion:', round(target_count[positive_class] / target_count[negative_class], 2), ': 1')
values = {'Original': [target_count[positive_class], target_count[negative_class]]}

figure()
bar_chart(target_count.index, target_count.values, title='Class balance')
savefig(f'data/results/{file}_balance.png')

df_positives = original[original[class_var] == positive_class]
df_negatives = original[original[class_var] == negative_class]

#UnderSample

from pandas import concat, DataFrame

df_neg_sample = DataFrame(df_negatives.sample(len(df_positives)))
df_under = concat([df_positives, df_neg_sample], axis=0)
df_under.to_csv(f'data/{file}_under.csv', index=False)
values['UnderSample'] = [len(df_positives), len(df_neg_sample)]
print('Minority class=', positive_class, ':', len(df_positives))
print('Majority class=', negative_class, ':', len(df_neg_sample))
print('Proportion:', round(len(df_positives) / len(df_neg_sample), 2), ': 1')

#OverSample

from pandas import concat, DataFrame

df_pos_sample = DataFrame(df_positives.sample(len(df_negatives), replace=True))
df_over = concat([df_pos_sample, df_negatives], axis=0)
df_over.to_csv(f'data/{file}_over.csv', index=False)
values['OverSample'] = [len(df_pos_sample), len(df_negatives)]
print('Minority class=', positive_class, ':', len(df_pos_sample))
print('Majority class=', negative_class, ':', len(df_negatives))
print('Proportion:', round(len(df_pos_sample) / len(df_negatives), 2), ': 1')

#SMOTE

from pandas import Series
from imblearn.over_sampling import SMOTE

smote = SMOTE(sampling_strategy='minority', random_state=0)
y = original.pop(class_var).values
X = original.values

smote_X, smote_y = smote.fit_resample(X, y)
df_smote = concat([DataFrame(smote_X), DataFrame(smote_y)], axis=1)
df_smote.columns = list(original.columns) + [class_var]
df_smote.to_csv(f'data/{file}_smote.csv', index=False)

smote_target_count = Series(smote_y).value_counts()
values['SMOTE'] = [smote_target_count[positive_class], smote_target_count[negative_class]]
print('Minority class=', positive_class, ':', smote_target_count[positive_class])
print('Majority class=', negative_class, ':', smote_target_count[negative_class])
print('Proportion:', round(smote_target_count[positive_class] / smote_target_count[negative_class], 2), ': 1')

#Supestamente um grafico que compara os 3

from matplotlib.pyplot import figure, show
from ds_charts import multiple_bar_chart

figure()
multiple_bar_chart([positive_class, negative_class], values, title='Target', xlabel='frequency', ylabel='Class balance')

#Train-Test Splitting
#Para o codigo que se segue deviamos ter um ficheiro com os dados de treino e outro com os de teste
import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np

train_data, test_data = train_test_split(df_smote, test_size=0.2, random_state=0)

# Save your training and test data into separate files
train_data.to_csv(f'data/{file}_blc_smote_train.csv', index=False)
test_data.to_csv(f'data/{file}_blc_smote_test.csv', index=False)

# Save your training and test data into separate Numpy files
np.save(f'data/{file}_blc_smote_train', train_data)
np.save(f'data/{file}_blc_smote_test', test_data)

#NaiveBayes

from numpy import ndarray
from pandas import DataFrame, read_csv, unique
from matplotlib.pyplot import figure, savefig, show
from sklearn.naive_bayes import GaussianNB
from ds_charts import plot_evaluation_results, bar_chart

target = 'target'

train: DataFrame = read_csv(f'data/{file}_blc_smote_train.csv')
trnY: ndarray = train.pop(target).values
trnX: ndarray = train.values
labels = unique(trnY)
labels.sort()

test: DataFrame = read_csv(f'data/{file}_blc_smote_test.csv')
tstY: ndarray = test.pop(target).values
tstX: ndarray = test.values

clf = GaussianNB()
clf.fit(trnX, trnY)
prd_trn = clf.predict(trnX)
prd_tst = clf.predict(tstX)
plot_evaluation_results(labels, trnY, prd_trn, tstY, prd_tst)
savefig(f'data/results/{file}_blc_nb_smote.png')

#Comparison of NB models

from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB, CategoricalNB
from sklearn.metrics import accuracy_score

estimators = {'GaussianNB': GaussianNB(),
              #'MultinomialNB': MultinomialNB(),
              #'BernoulliNB': BernoulliNB()
              #'CategoricalNB': CategoricalNB
              }

xvalues = []
yvalues = []
for clf in estimators:
    xvalues.append(clf)
    estimators[clf].fit(trnX, trnY)
    prdY = estimators[clf].predict(tstX)
    yvalues.append(accuracy_score(tstY, prdY))

figure()
bar_chart(xvalues, yvalues, title='Comparison of Naive Bayes Models', ylabel='accuracy', percentage=True)
savefig(f'data/results/{file}_blc_nb_study_smote.png')

print('\nend of script\n')