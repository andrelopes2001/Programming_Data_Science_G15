from pandas import read_csv
from pandas.plotting import register_matplotlib_converters
import pandas as pd


register_matplotlib_converters()
file = 'ds_G15'
filename = 'small_ca_monthly_data.csv'
data = read_csv(filename, index_col='station', na_values='', parse_dates=True, infer_datetime_format=True)

#Missing Values Imputation

from matplotlib.pyplot import figure, savefig
from ds_charts import bar_chart

mv = {}
figure()
for var in data:
    nr = data[var].isna().sum()
    if nr > 0:
        mv[var] = nr

# Dropping missing values

# defines the number of records to discard entire columns
threshold = data.shape[0] * 0.90

missings = [c for c in mv.keys() if mv[c]>threshold]
df = data.drop(columns=missings, inplace=False)
#df.to_csv(f'data/{file}_drop_columns_mv.csv', index=True)
print('Dropped variables', missings)

from sklearn.impute import SimpleImputer
from pandas import concat, DataFrame
from ds_charts import get_variable_types
from numpy import nan

tmp_nr, tmp_sb, tmp_bool = None, None, None
variables = get_variable_types(df)
numeric_vars = variables['Numeric']
symbolic_vars = variables['Symbolic']
binary_vars = variables['Binary']

if len(numeric_vars) > 0:
    imp = SimpleImputer(strategy='median', missing_values=nan, copy=True)
    tmp_nr = DataFrame(imp.fit_transform(data[numeric_vars]), columns=numeric_vars)
if len(symbolic_vars) > 0:
    imp = SimpleImputer(strategy='median', missing_values=nan, copy=True)
    tmp_sb = DataFrame(imp.fit_transform(data[symbolic_vars]), columns=symbolic_vars)
if len(binary_vars) > 0:
    imp = SimpleImputer(strategy='median', missing_values=nan, copy=True)
    tmp_bool = DataFrame(imp.fit_transform(data[binary_vars]), columns=binary_vars)

df = concat([tmp_nr, tmp_sb, tmp_bool], axis=1)
df.index = data.index
df.to_csv(f'data/{file}_mv_median.csv', index=True)
df.describe(include='all')

#Train-Test Splitting

#Para o codigo que se segue deviamos ter um ficheiro com os dados de treino e outro com os de teste
import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np

train_data, test_data = train_test_split(df, test_size=0.2, random_state=0)

# Save your training and test data into separate files
train_data.to_csv(f'data/{file}_mv_median_train.csv', index=False)
test_data.to_csv(f'data/{file}_mv_median_test.csv', index=False)

# Save your training and test data into separate Numpy files
np.save(f'data/{file}_mv_median_train', train_data)
np.save(f'data/{file}_mv_median_test', test_data)

#NaiveBayes

from numpy import ndarray
from pandas import DataFrame, read_csv, unique
from matplotlib.pyplot import figure, savefig, show
from sklearn.naive_bayes import GaussianNB
from ds_charts import plot_evaluation_results, bar_chart

target = 'target'

train: DataFrame = read_csv(f'data/{file}_mv_median_train.csv')
trnY: ndarray = train.pop(target).values
trnX: ndarray = train.values
labels = unique(trnY)
labels.sort()

test: DataFrame = read_csv(f'data/{file}_mv_median_test.csv')
tstY: ndarray = test.pop(target).values
tstX: ndarray = test.values

clf = GaussianNB()
clf.fit(trnX, trnY)
prd_trn = clf.predict(trnX)
prd_tst = clf.predict(tstX)
plot_evaluation_results(labels, trnY, prd_trn, tstY, prd_tst)
savefig(f'data/results/{file}_mv_nb_median.png')

#Comparison of NB models

from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB, CategoricalNB
from sklearn.metrics import accuracy_score

estimators = {'GaussianNB': GaussianNB(),
              #'MultinomialNB': MultinomialNB(),
              #'BernoulliNB': BernoulliNB()
              #'CategoricalNB': CategoricalNB
              }

xvalues = []
yvalues = []
for clf in estimators:
    xvalues.append(clf)
    estimators[clf].fit(trnX, trnY)
    prdY = estimators[clf].predict(tstX)
    yvalues.append(accuracy_score(tstY, prdY))

figure()
bar_chart(xvalues, yvalues, title='Naive Bayes Accuracy', ylabel='accuracy', percentage=True)
savefig(f'data/results/{file}_mv_nb_study_median.png')

print('\nend of script\n')