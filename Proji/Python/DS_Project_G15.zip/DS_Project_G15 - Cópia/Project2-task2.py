

from pandas import read_csv
from pandas.plotting import register_matplotlib_converters
import pandas as pd


register_matplotlib_converters()
file = 'small_ca'
filename = 'small_ca_monthly_data.csv'
data = read_csv(filename, index_col='station', na_values='', parse_dates=True, infer_datetime_format=True)

#Missing Values Imputation

from matplotlib.pyplot import figure, savefig
from ds_charts import bar_chart

mv = {}
figure()
for var in data:
    nr = data[var].isna().sum()
    if nr > 0:
        mv[var] = nr

bar_chart(list(mv.keys()), list(mv.values()), title='Nr of missing values per variable', xlabel='variables', ylabel='nr missing values')
savefig(f'{file}_missing_values.pdf')


#Dropping missing values

# defines the number of records to discard entire columns
threshold = data.shape[0] * 0.90

missings = [c for c in mv.keys() if mv[c]>threshold]
df = data.drop(columns=missings, inplace=False)
df.to_csv(f'{file}_drop_columns_mv.csv', index=True)
print('Dropped variables', missings)

# defines the number of variables to discard entire records
threshold = df.shape[1] * 0.50

df = df.dropna(thresh=threshold, inplace=False)
df.to_csv(f'{file}_drop_records_mv.csv',index=True)
print(df.shape)


df.apply(pd.to_numeric)

#Discretize targer parameter
aux = pd.get_dummies(df,columns=['target'])
df['target'] = aux['target_True']
df = df.dropna(axis=1, how='all')




#Filling missing values

from sklearn.impute import SimpleImputer
from pandas import concat, DataFrame
from ds_charts import get_variable_types
from numpy import nan

tmp_nr, tmp_sb, tmp_bool = None, None, None
variables = get_variable_types(df)
numeric_vars = variables['Numeric']
symbolic_vars = variables['Symbolic']
binary_vars = variables['Binary']

tmp_nr, tmp_sb, tmp_bool = None, None, None
if len(numeric_vars) > 0:
    imp = SimpleImputer(strategy='mean', missing_values=nan, copy=True)
    tmp_nr = DataFrame(imp.fit_transform(df[numeric_vars]), columns=numeric_vars)
if len(symbolic_vars) > 0:
    imp = SimpleImputer(strategy='most_frequent', missing_values=nan, copy=True)
    tmp_sb = DataFrame(imp.fit_transform(df[symbolic_vars]), columns=symbolic_vars)
if len(binary_vars) > 0:
    imp = SimpleImputer(strategy='most_frequent', missing_values=nan, copy=True)
    tmp_bool = DataFrame(imp.fit_transform(df[binary_vars]), columns=binary_vars)

df = concat([tmp_nr, tmp_sb, tmp_bool], axis=1)
#df.index = df.index
df.to_csv(f'{file}_mv_most_frequent.csv', index=True)
df.describe(include='all')

#Scalling

variable_types = get_variable_types(df)
numeric_vars = variable_types['Numeric']
symbolic_vars = variable_types['Symbolic']
boolean_vars = variable_types['Binary']

df_nr = df[numeric_vars]
df_sb = df[symbolic_vars]
df_bool = df[boolean_vars]

from sklearn.preprocessing import StandardScaler
from pandas import DataFrame, concat
#standart scaller

transf = StandardScaler(with_mean=True, with_std=True, copy=True).fit(df_nr)
tmp = DataFrame(transf.transform(df_nr), index=df.index, columns= numeric_vars)
norm_data_zscore = concat([tmp,df_bool], axis=1)
norm_data_zscore.to_csv(f'{file}_scaled_zscore.csv', index=False)

from sklearn.preprocessing import MinMaxScaler
from pandas import DataFrame, concat

transf = MinMaxScaler(feature_range=(0, 1), copy=True).fit(df_nr)
tmp = DataFrame(transf.transform(df_nr), index=df.index, columns= numeric_vars)
norm_data_minmax = concat([tmp, df_bool], axis=1)
norm_data_minmax.to_csv(f'{file}_scaled_minmax.csv', index=False)
print(norm_data_minmax.describe())

from matplotlib.pyplot import subplots, show

fig, axs = subplots(1, 3, figsize=(20,10),squeeze=False)
axs[0, 0].set_title('Original data')
df.boxplot(ax=axs[0, 0])
axs[0, 1].set_title('Z-score normalization')
norm_data_zscore.boxplot(ax=axs[0, 1])
axs[0, 2].set_title('MinMax normalization')
norm_data_minmax.boxplot(ax=axs[0, 2])
show()

norm_data_zscore.to_csv(f'{file}scaled_zscore.csv', index=False)


#Train-Test split

# import modules
 
from sklearn.model_selection import train_test_split

# get the locations
X = df.iloc[0:-1,0:-1]
y = df.iloc[0:-1,-1]

# split the dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=50)

# test_size parameter specifies the proportion of the data to be used for testing
# random_state is used to ensure that the data is split in a reproducible way


#Data Balancing

from pandas import read_csv
from matplotlib.pyplot import figure, savefig, show
from ds_charts import bar_chart

filename = 'data/unbalanced.csv'
file = "unbalanced"
original = read_csv(filename, sep=',', decimal='.')
class_var = 'Outcome'
target_count = original[class_var].value_counts()
positive_class = target_count.idxmin()
negative_class = target_count.idxmax()
#ind_positive_class = target_count.index.get_loc(positive_class)
print('Minority class=', positive_class, ':', target_count[positive_class])
print('Majority class=', negative_class, ':', target_count[negative_class])
print('Proportion:', round(target_count[positive_class] / target_count[negative_class], 2), ': 1')
values = {'Original': [target_count[positive_class], target_count[negative_class]]}

figure()
bar_chart(target_count.index, target_count.values, title='Class balance')
savefig(f'images/{file}_balance.png')
show()



